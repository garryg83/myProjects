package com.tomtom;

import java.io.BufferedInputStream;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.io.InputStream;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Properties;
import java.util.regex.Pattern;
import org.apache.commons.io.*;

import com.tomtom.model.Input;
import com.tomtom.model.Output;

public class PatternCounter {

	public Output countPattern(Input input) {

		Output output = new Output();
		LinkedHashMap<String, Integer> hm = new LinkedHashMap<String, Integer>();
		Properties prop = new Properties();

		String strpat = "";
		String strContent = "";
		int splitcount = 0;
		try (InputStream propStream = new FileInputStream(
				"src/main/resources/pattern.properties");
				InputStream inputFile = new FileInputStream(input.getPath());
				BufferedInputStream bif = new BufferedInputStream(inputFile)) {

			prop.load(propStream);
			String[] propArr = prop.getProperty(
					Integer.toString(input.getPattern())).split("\\+");
			splitcount = Integer.parseInt(propArr[0]);

			strpat = prop.getProperty(propArr[1]);

			strContent = IOUtils.toString(bif, "UTF-8");

		} catch (FileNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}

		Pattern pattern = Pattern.compile(strpat);

		String[] stringArray = strContent.trim().split("\\s+");

		List<String> finalList = splitString(splitcount, stringArray);

		for (String str : finalList) {
			if (pattern.matcher(str).matches()) {
				if (hm.containsKey(str)) {
					hm.put(str, hm.get(str) + 1);
				} else {
					hm.put(str, 1);
				}

			}

		}
		System.out.println("Output is:: ");

		for (String key : hm.keySet()) {
          
			System.out.println(key + "," + hm.get(key));

		}
		output.setResult(hm);

		return output;

	}

	private List<String> splitString(int splitcount, String[] stringArray) {
		List<String> finalList = new ArrayList<String>();
		if (splitcount <= 0) {

			finalList = Arrays.asList(stringArray);

		}

		else {
			for (int i = 0; i < stringArray.length; i++) {
				StringBuilder val = new StringBuilder();

				if (i < stringArray.length - (splitcount - 1)) {
					for (int j = 0; j < splitcount; j++) {
						if (j == 0) {
							val.append(stringArray[i + j]);
						} else {
							val.append(" ").append(stringArray[i + j]);
						}

					}

					finalList.add(val.toString());

				}

			}

		}
		return finalList;
	}

}
