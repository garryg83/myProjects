package com.tomtom.model;

import java.util.LinkedHashMap;
import java.util.List;

public class Output {
	private LinkedHashMap<String, Integer> result;

	public LinkedHashMap<String, Integer> getResult() {
		return result;
	}

	public void setResult(LinkedHashMap<String, Integer> result) {
		this.result = result;
	}	
	
	

}
