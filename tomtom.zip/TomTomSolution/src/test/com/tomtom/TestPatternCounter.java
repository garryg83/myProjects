package com.tomtom;

import static org.junit.Assert.*;

import java.util.LinkedHashMap;
import java.util.Scanner;

import org.junit.Test;

import com.tomtom.model.Input;
import com.tomtom.model.Output;

import static org.hamcrest.CoreMatchers.*;
import static org.hamcrest.MatcherAssert.assertThat;

public class TestPatternCounter {

	@Test
	public void testCountPattern() {

		LinkedHashMap<String, Integer> expected = new LinkedHashMap<String, Integer>();
		Scanner input = new Scanner(System.in);
		System.out.print("Enter file path:: ");
		String path = input.next();
		System.out.print("Enter pattern:: ");
		int pattern = input.nextInt();
		input.close();
		if (pattern == 1) {
			expected.put("a", 2);
			expected.put("big", 2);
			expected.put("surprise", 2);
			expected.put("hello", 1);
			expected.put("is", 1);

		} else if (pattern == 2) {
			expected.put("1000", 2);
			expected.put("2000", 1);
		} else if(pattern==3) {
			expected.put("1000 a big", 1);
			expected.put("a big surprise", 2);
			expected.put("big surprise 2000", 1);
			expected.put("surprise 2000 hello", 1);
			expected.put("2000 hello is", 1);
			expected.put("hello is a", 1);
			expected.put("is a big", 1);
			expected.put("big surprise 1000", 1);

		}

		patternTester(expected, path, pattern);
	}

	private void patternTester(LinkedHashMap<String, Integer> expected,
			String path, int pattern) {
		Input ip = new Input();
		ip.setPath(path);
		ip.setPattern(pattern);
		PatternCounter pc = new PatternCounter();
		Output op = pc.countPattern(ip);
		/* assertEquals(expected, op.getResult()); */
		assertThat(op.getResult(), is(expected));
	}

}
